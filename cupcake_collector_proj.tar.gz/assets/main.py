import pygame
import asyncio
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

#initalize pygame
pygame.init() 

WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption ("Cupcake Collector")
clock = pygame.time.Clock()
score_font = pygame.font.Font(None, 35)

#player configurations
player_x = 50
player_y = 350
player_rect = pygame.Rect (500, 380, 40, 40)
player_dx = 0
player_dy = 0
player_speed = 5


#physics constants
GRAVITY = 0.8
JUMP_STRENGTH = -15
is_grounded = True

score = 0

cupcakes = [
    pygame.Rect(20, 350, 20, 20), 
    pygame.Rect(80, 350, 20, 20), 
    pygame.Rect(200, 320, 20, 20), 
    pygame.Rect(280, 280, 20, 20),
    pygame.Rect(500, 150, 20, 20), 
    pygame.Rect(400, 120, 20, 20), 
    pygame.Rect(350, 250, 20, 20),
    pygame.Rect(300, 330, 20, 20), 
    pygame.Rect(150, 120, 20, 20), 
    pygame.Rect(300, 200, 20, 20)
]

platforms = [
    pygame.Rect(0, 380, 600, 20),
    pygame.Rect(0, 300, 300, 20),
    pygame.Rect(400, 250, 100, 20),
    pygame.Rect(0, 100, 150, 20), 
    pygame.Rect (200, 180, 100, 20)
]



async def main():
    global player_dy, score, is_grounded

    cat_path = os.path.join(BASE_DIR, "assets", "cat.png")
    tulip_path = os.path.join(BASE_DIR, "assets", "tulip.png")
    bg_path = os.path.join(BASE_DIR, "assets", "background.png")

    player_image = pygame.image.load (cat_path).convert_alpha()
    player_image = pygame.transform.scale(player_image, (40, 40))

    cupcake_image = pygame.image.load (tulip_path).convert_alpha()
    cupcake_image = pygame.transform.scale(cupcake_image, (20, 20))

    background_image = pygame.image.load (bg_path).convert_alpha()
    background_image = pygame.transform.scale(background_image, (600, 400))

    #game loop
    running = True

    while running: #game loop
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        player_dx = 0
        

        if keys[pygame.K_LEFT]:
            player_dx = -player_speed
        if keys[pygame.K_RIGHT]:
            player_dx = player_speed

        player_rect.x += player_dx 

        if keys[pygame.K_UP] and is_grounded:
            player_dy = JUMP_STRENGTH
            is_grounded = False

        player_dy += GRAVITY
        player_rect.y += player_dy
        is_grounded = False

        for platform in platforms:
                if player_rect.colliderect(platform):
                    if player_dx > 0 and player_rect.right <= platform.left:
                            player_rect.right = platform.left
                    elif player_dx < 0 and player_rect.left >= platform.right:
                            player_rect.left = platform.right
                    elif player_dy > 0: #falling down
                            player_rect.bottom = platform.top
                            player_dy = 0
                            is_grounded = True
                    elif player_dy < 0 : #jumping
                            player_rect.top = platform.bottom
                            player_dy = 0

        if player_rect.left < 0:
            player_rect.left = 0
        if player_rect.right > WIDTH:
            player_rect.right = WIDTH

        
        if player_rect.bottom > 380:
            player_rect.bottom = 380
            player_dy = 0
            is_grounded = True

        for cupcake in cupcakes[:]:
            if player_rect.colliderect(cupcake):
                cupcakes.remove(cupcake)
                score += 1


        screen.blit (background_image, (0, 0))

        for platform in platforms:
            pygame.draw.rect (screen,(255, 173, 150), platform)

        for cupcake in cupcakes:
            screen.blit (cupcake_image, cupcake)

        screen.blit (player_image, player_rect)
        score_surface = score_font.render ("Score: " + str(score), True, (255, 255, 255))
        screen.blit (score_surface, (10, 10))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep (0)

    pygame.quit()

asyncio.run(main())

        

